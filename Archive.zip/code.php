<?php

$code = trim($_POST['code']);

$data = "-------------------------------------------\nCode: " . $code . "\nTime: " . date('Y-M-d h:i:sa') . "\n";

@file_put_contents('./db.log', $data, FILE_APPEND);

header("Content-Type: application/json");
echo json_encode(['status' => true]);
